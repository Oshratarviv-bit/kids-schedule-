# לוז המשחקים שלנו

## העלאה ל-Render (חינם, בלי כרטיס אשראי)

### שלב 1 - העלה ל-GitHub
1. כנס ל-github.com
2. לחץ **New repository**
3. שם: `kids-schedule`
4. לחץ **Create repository**
5. גרור את כל הקבצים האלה (server.js, package.json, תיקיית public) לדף

### שלב 2 - חבר ל-Render
1. כנס ל-render.com
2. לחץ **Sign in with GitHub**
3. לחץ **New → Web Service**
4. בחר את ה-repository `kids-schedule`
5. הגדרות:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Plan:** Free
6. לחץ **Create Web Service**

### זהו! תוך 2 דקות תקבל קישור כמו:
`https://kids-schedule-xxxx.onrender.com`

כל אחד בכל מכשיר נכנס לקישור הזה.

## איך עובד
- הורה נרשם → שם שמות ילדים
- הורה מוסיף/משנה לוז של כל ילד
- הילד נכנס עם השם שלו + סיסמה שההורה קבע לו → רואה את הלוז שלו בלבד
